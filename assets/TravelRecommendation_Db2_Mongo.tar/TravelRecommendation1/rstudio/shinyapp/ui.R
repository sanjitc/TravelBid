library(shiny)
library(shinydashboard)


#################################################################
#javascript for sidepanel#
#################################################################
jsc <- '
$(document).ready(function() 
{
  $(".sidebar-menu").children("li").on("click", function() 
  {
    $("#tdates,#budget,#tduration, #hc").slideToggle();
  });
});
'

############################################################
#dashboard header and sidebar
###########################################################
dashboardPage(
  skin = "purple",
  
  dashboardHeader(
    title = "Travel Recommendation", titleWidth = 300
  ),
  dashboardSidebar(
    width = 300,
    br(),
    
    sidebarMenu(
      list(
        #BUDGET SLIDER
        menuItem(
          "Budget",
          tabName = "widgets",
          icon = icon("th")),
          div(id ="budget",style="display: none;",sliderInput("budget", label="Price Range ($)", min = 100, max = 1000,value =1)),
       
        #HOTELS AND RENTAL CARS 
        menuItem("Hotels and Rental Cars",
                 tabName = "rental cars",
                 icon = icon("th")),div(id ="hc",style="display: none;",
                 selectInput("borough", "Borough",
                 list("Manhattan","Queens", "Brooklyn", "The Bronx", "Staten Island"), 
                 selected = "Manhattan",selectize = FALSE)),
                 div(id ="hc",style="display: none;", 
                 
                 selectInput("hotelrating", "Hotel Rating",
                 list("1"," 1.5", "2", "2.5", "3","3.5","4","4.5","5"),selectize = FALSE)),
                 div(id ="hc",style="display: none;",
                     
                 selectInput("carsize", "Car Type",
                 list("Economy","Compact", "Midsize","Fullsize","Preminum","Luxury","Minivan", "Convertible" ,"Midsize SUV", "Standard SUV","Fullsize SUV"), 
                 selected = "Economy",selectize = FALSE)),
        
        br(),
        
        div(style="display:inline-block;width:32%;text-align: center;",submitButton("Submit"))
      )
    )
  ),
  ############################################################################
  # MAIN PANEL
  ############################################################################
  dashboardBody(
    tags$head(tags$script(jsc)),
    tags$head(tags$style(
      HTML('.wrapper {height: auto !important; position:relative; overflow-x:hidden; overflow-y:hidden}')) ),
    tabItem(tabName = "movies",
            fluidRow(
              box(
                width = 10, status = "info", solidHead = TRUE,
                title = "Best Price",
                tableOutput("tbTable"),collapsible = TRUE),
              box(
                width = 10, status = "info", solidHead = TRUE,
                title = "Best Experience",
                tableOutput("tbTable1"),collapsible = TRUE),
              HTML('<br/>')
            )
      )
  )
  
)







