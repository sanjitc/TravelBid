library(shiny)
library(RJDBC)

server <- function(input,output,session) 
  
{ 
  myData <- reactive({
    req(input$budget)
    req(input$borough)
    req(input$hotelrating)
    req(input$carsize)
    
    #### JDBC credentials - Section 1 ####
    driverClassName <- "com.ibm.db2.jcc.DB2Driver"
    driverPath <- "/dbdrivers/db2jcc4.jar"
    url <- "jdbc:db2://dv-server.zen.svc.cluster.local:32051/bigsql"
    databaseUsername <- "user999"
    databasePassword <- "s3?1%m-T6UkLp4#I"
    drv <- JDBC(driverClassName, driverPath)
    
    #connect to database 
    dbhandle <- dbConnect(drv, url, databaseUsername, databasePassword)
    
    
    #### Build Query - Section 1 ####
    # Search best price
    selStr <- "SELECT HOTEL,CARMODEL,HOTELRATING,COST,CARSIZE FROM TRAVELDATA1 
    WHERE  COST <= ?
    AND BOROUGH = ?
    AND HOTELRATING = ?
    AND CARSIZE = ?
    ORDER BY COST
    FETCH FIRST 10 ROWS ONLY;"
    
    #store results
    res <- dbSendQuery(dbhandle,selStr,input$budget,input$borough,input$hotelrating,input$carsize)
    
    x <- dbFetch(res)
    
    #close the connection
    dbDisconnect(dbhandle)
    
    #return results
    x
    
  })
  
  myData1 <- reactive({
    req(input$budget)
    req(input$borough)
    req(input$hotelrating)
    req(input$carsize)
    
    #### JDBC credentials - Section 2 ####
    driverClassName <- "com.ibm.db2.jcc.DB2Driver"
    driverPath <- "/dbdrivers/db2jcc4.jar"
    url <- "jdbc:db2://dv-server.zen.svc.cluster.local:32051/bigsql"
    databaseUsername <- "user999"
    databasePassword <- "s3?1%m-T6UkLp4#I"
    drv <- JDBC(driverClassName, driverPath)
   
    #connect to database 
    dbhandle <- dbConnect(drv, url, databaseUsername, databasePassword)
    
    #### Build Query - Section 2 ####
    # Display best experience 
    selStr1 <- "SELECT HOTEL,CARMODEL,HOTELRATING,COST,CARSIZE
    FROM   USER999.TRAVELDATA1 
    WHERE  COST <= ?
    AND BOROUGH = ?
    AND HOTELRATING > ?
    AND SIZEID IN (
      SELECT USER999.RENTALCAR.SIZEID 
      FROM USER999.RENTALCAR 
      WHERE USER999.RENTALCAR.SIZEID NOT IN (
        SELECT UNIQUE  USER999.RENTALCAR.SIZEID 
        FROM USER999.RENTALCAR 
        WHERE USER999.RENTALCAR.SIZE = ?
        ORDER BY USER999.RENTALCAR.SIZEID DESC
      )
    )
    ORDER BY COST DESC,SIZEID DESC
    FETCH FIRST 10 ROWS ONLY;"
    
    #store results
    res1 <- dbSendQuery(dbhandle,selStr1,input$budget,input$borough,input$hotelrating,input$carsize)
    
    x1 <- dbFetch(res1)
    
    #close the connection
    dbDisconnect(dbhandle)

    #return results
    x1
  })
  
  
  
  #####################################################
  ### table for Query#1 
  ####################################################
  output$tbTable <- 
    renderTable((myData()),align = 'c')
  #####################################################
  ### table for Query#2
  ####################################################
  output$tbTable1 <- 
    renderTable((myData1()))
  
  
}
